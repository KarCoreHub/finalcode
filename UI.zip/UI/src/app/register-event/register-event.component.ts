import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RouterService } from '../services/router.service';
import { AuthenticationService } from '../services/authentication.service';
import { FormControl, FormGroup, FormGroupDirective } from '@angular/forms';

export class EventDetail {
  eventId: string='';  
  eventLocation: string=''; 
  eventName:string='';
  eventDetails: string=''; 
  eventDate:string='';
}

export class  EventRegister {  
  eventregisterid: string='';
  eventId: string='';
  userId: string='';
}
@Component({
  selector: 'app-register-event',
  templateUrl: './register-event.component.html',
  styleUrls: ['./register-event.component.css']
})
export class RegisterEventComponent  {
 
  errorMessage: string;
  submitMessage:string;
  eventRegister:EventRegister;
  eventId = new FormControl();
  eventName = new FormControl();
  eventLocation = new FormControl();
  eventdetails= new FormControl();
  eventdate= new FormControl();
  
  registerEventForm: FormGroup = new FormGroup({
    eventId: new FormControl(),
    eventName: new FormControl(),
    eventLocation: new FormControl(),
    eventDetails: new FormControl(),
    eventDate: new FormControl()    
  });
  @ViewChild(FormGroupDirective)
  formGroupDirective: FormGroupDirective;
  
  constructor(private authenticateService: AuthenticationService    
    ,private route: ActivatedRoute,private routerService: RouterService) {   
    
  } 
  

  AddEvent() 
  {
    this.eventRegister = new EventRegister();
    this.eventRegister.eventId=this.registerEventForm.value["eventId"];
    //this.registerEventForm.value
    this.authenticateService.RegisterEvent(this.registerEventForm.value)
    .subscribe(res => {       
      alert("Event Added Successfully");
      //this.registerEventForm.c
      this.routerService.routeToDashboard();
    },
      err => {
        if (err.error) {
          this.errorMessage = err.error.message;
        } else {
          this.errorMessage = err.message;
        }

      });   
  }
}
