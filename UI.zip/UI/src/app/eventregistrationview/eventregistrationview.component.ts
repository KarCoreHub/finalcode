import { Component,OnInit,DoCheck } from '@angular/core';

import { AuthenticationService } from '../services/authentication.service';

export class  EventRegister {  
  eventregisterid: string='';
  eventId: string='';
  userId: string='';
}

@Component({
  selector: 'app-report-view',
  templateUrl: './eventregistrationview.component.html',
  styleUrls: ['./eventregistrationview.component.css']
})
export class EventRegistrationViewComponent implements OnInit,DoCheck {

  eventregisters: Array<EventRegister> = new Array<EventRegister>(); 
  errorMessage: string;
  authenticateService:AuthenticationService;
  
  constructor(private authenticateServ: AuthenticationService) {  
    this.authenticateService = authenticateServ;    
  }

  ngOnInit() {    
    this.authenticateService.fetchEventsReportFromServer();
    this.eventregisters = this.authenticateService.getEventReportList();          
  }

  ngDoCheck(){    
    this.eventregisters = this.authenticateService.getEventReportList();   
  }
}
