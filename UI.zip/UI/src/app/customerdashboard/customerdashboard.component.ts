import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';

import { AuthenticationService } from '../services/authentication.service';

import { FormGroupDirective } from '@angular/forms';
import { RegisteruserComponent } from '../registeruser/registeruser.component';


@Component({
  selector: 'customerdashboard',
  templateUrl: './customerdashboard.component.html',
  styleUrls: ['./customerdashboard.component.css']
})

export class customerdashboardComponent {
  authenticateService:AuthenticationService;
  constructor(private authenticateSer: AuthenticationService,private dialog: MatDialog) {     
    this.authenticateService=authenticateSer;
  }
  @ViewChild(FormGroupDirective)
  formGroupDirective: FormGroupDirective;
 
  RegisterEvent() {
    this.dialog.open(RegisteruserComponent, {
      data: {       
      }
    }).afterClosed().subscribe(result => {     
    })
  }
  /*
  CancelTrip() {
    this.dialog.open(CancelTripComponent, {
      data: {       
      }
    }).afterClosed().subscribe(result => {      
    })
  }
  
  TrackTrip() {
    this.dialog.open(TrackTripComponent, {
      data: {        
      }
    }).afterClosed().subscribe(result => {      
    })
  }*/
}
