import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { Travel } from '../Travel';
import { Vehicle } from '../Vehicle';

export class EventDetail {
  eventId: string='';  
  eventLocation: string=''; 
  eventName:string='';
  eventDetails: string=''; 
  eventDate:string='';
}

export class  EventRegister {  
  eventregisterid: string='';
  eventId: string='';
  userId: string='';
}

@Injectable()
export class AuthenticationService {
  travel: Travel;
  eventRegisters: Array<EventRegister>;
  eventsReport: Array<EventRegister>;
  eventList:Array<EventDetail>;
  type:string='';
  serviceUrl:string='http://localhost:29460/';
  //serviceUrl:string='https://otmsserviceapi.azurewebsites.net/';
  errorMessage: string = '';
  constructor(private httpClient: HttpClient) {
     this.eventRegisters= new Array<EventRegister>();
  }

  fetchEventsFromServer() {
    const headers = new HttpHeaders().set("content-type", "text/plain")
      .set('Authorization', 'Bearer ' + this.getBearerToken())
     .set('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'GET');
      return this.httpClient.get<Array<EventDetail>>(this.serviceUrl+'auth/ViewEvents', { headers })
     .subscribe((eventlist) =>  this.eventList = eventlist)
     , error => {
       this.errorMessage = error.message;
     };          
  }

  fetchEventsReportFromServer() {
    const headers = new HttpHeaders().set("content-type", "text/plain")
      .set('Authorization', 'Bearer ' + this.getBearerToken())
     .set('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'GET');
      return this.httpClient.get<Array<EventRegister>>(this.serviceUrl+'auth/ViewEventWithUserId', { headers })
     .subscribe((eventsReport) =>  this.eventsReport = eventsReport)
     , error => {
       this.errorMessage = error.message;
     };          
  }

  fetchEventRegisterList() {
    const headers = new HttpHeaders().set("content-type", "text/plain")
      .set('Authorization', 'Bearer ' + this.getBearerToken())
     .set('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'GET');
      return this.httpClient.get<Array<EventRegister>>(this.serviceUrl+'auth/ViewEventRegisters', { headers })
     .subscribe((eventRegisterList) =>  this.eventRegisters = eventRegisterList)
     , error => {
        this.errorMessage = error.message;
      };          
  }

  getEventList() {
    return this.eventList;
  }

  getEventReportList() {
    return this.eventsReport;
  }
  
  getType() {
    return this.type;
  }

  registerUser(data) {
    const headers = new HttpHeaders().set("content-type", "application/json").set
      ('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'POST');
    return this.httpClient.post(this.serviceUrl+'auth/register', data, {
      headers
    });
  }
  authenticateUser(data) {
    const headers = new HttpHeaders().set("content-type", "application/json").set
      ('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'POST');
    return this.httpClient.post(this.serviceUrl+'auth/login', data, {
      headers
    });
  }

 getUserType(data) {     
     const headers = new HttpHeaders().set("content-type", "application/json").set
      ('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'POST');
    return this.httpClient.post(this.serviceUrl+'auth/GetUserType', data, {
      headers
    });
  }

  RegisterEvent(data) {
    const headers = new HttpHeaders().set("content-type", "application/json").set
      ('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'POST');
    return this.httpClient.post(this.serviceUrl+'auth/registerEvent', data, {
      headers
    });
  }

  BookEvent(data) {
    const headers = new HttpHeaders().set("content-type", "application/json").set
      ('Access-Control-Allow-Origin', '*').set('Access-Control-Allow-Methods', 'POST');
    return this.httpClient.post(this.serviceUrl+'auth/registerUserEvent', data, {
      headers
    });
  }

  
  getToken(): string {
    let token = localStorage.getItem('bearerToken');
    return token ? token : "";
  }

  isAuthenticated(): boolean {
    let token = '';
    token = this.getToken();
    if (token === "null")
      token = '';
    // Check whether the token is expired or not
    // return true or false
    return token != "" ? true : false;
  }

  setBearerToken(token) {
    localStorage.setItem('bearerToken', token);
  }

  getBearerToken() {
    return localStorage.getItem('bearerToken');
  }

  getUserId() {
    return localStorage.getItem('userId');
  }
  setUserId(userId) {
    localStorage.setItem('userId', userId);
  }

  getUserPassword() {
    return localStorage.getItem('Password');
  }
  setUserPassword(Password) {
    localStorage.setItem('Password', Password);
  }

 
  setUserType(Type) {
    localStorage.setItem('UserType', Type);
  }

  isUserAuthenticated(token): Promise<boolean> {
    const headers = new HttpHeaders().set("content-type", "application/json");
    return this.httpClient.get(this.serviceUrl+'auth/IsUserAuthenticated', {
      headers
    })
      .pipe(map((res) => res["isAuthenticate"]))
      .toPromise();
  }

  logout() {   
    localStorage.removeItem('bearerToken');
    localStorage.removeItem('userId');    
    localStorage.removeItem('Password');    
  }
}