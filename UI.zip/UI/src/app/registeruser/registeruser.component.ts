import { Component, OnInit, ViewChild, DoCheck } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective } from '@angular/forms';
import { RouterService } from '../services/router.service';
import { AuthenticationService } from '../services/authentication.service';


export class EventDetail {
  eventId: string='';  
  eventLocation: string=''; 
  eventName:string='';
  eventDetails: string=''; 
  eventDate:string='';
}

export class  EventRegister {  
  eventregisterid: string='';
  eventid: string='';
  userid: string='';
}

@Component({
  selector: 'app-registeruser',
  templateUrl: './registeruser.component.html',
  styleUrls: ['./registeruser.component.css']
})
export class RegisteruserComponent implements OnInit,DoCheck {
  eventdetail: EventDetail=new EventDetail();
  eventregister: EventRegister= new EventRegister();
  errorMessage: string;
  eventSelectedValue: string;
  testData:any;
  authenticationServ: AuthenticationService;  

  eventDetailList: Array<EventDetail>;
  submitMessage: string;
  userType: string;
 
  Type = new FormControl();
  EventValue = new FormControl();
 
  registerForm: FormGroup = new FormGroup({
   
    Type: new FormControl(),
    EventValue: new FormControl()
    
  });
  @ViewChild(FormGroupDirective)
  formGroupDirective: FormGroupDirective;

  constructor(private _authService: AuthenticationService,
    private routerService: RouterService) { 
      this.authenticationServ=_authService;
      this.eventSelectedValue = '';   
    } 


  ngOnInit() {
    this.loadEvents();   
  } 

  ngDoCheck(){    
    this.eventDetailList = this.authenticationServ.getEventList(); 
  }

  
  loadEvents()
  {    
    this.authenticationServ.fetchEventsFromServer();
    this.eventDetailList = this.authenticationServ.getEventList();      
    
  }

  ConfirmEvent()
  {
    this.testData=this.registerForm.get("EventValue").value;
    if (( this.testData!== '' )&&( this.testData!== null )) {     
      
      this.eventregister.eventid=this.testData;
      
      this.eventregister.userid = this.authenticationServ.getUserId();
      //this.eventregister.active = true;
      this.authenticationServ.BookEvent(this.eventregister).subscribe(addedNote => {        
        alert("Event confirmed for User");
        this.routerService.routeToEmployeeDashboard();            
      },
        error => {
          this.errorMessage = error.message;
        }
      );
      
    } else {
      this.errorMessage = 'Please select the event to confirm';
    } 
   }

}
