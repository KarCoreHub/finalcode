import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { MatDialogModule } from '@angular/material/dialog';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';

import { AuthenticationService } from './services/authentication.service';
import { RouterService } from './services/router.service';
import { CanActivateRouteGuard } from './can-activate-route.guard';
import { RegisterComponent } from './register/register.component';

import {RegisterEventComponent} from './register-event/register-event.component';
import { admindashboardComponent } from './admindashboard/admindashboard.component';
import { customerdashboardComponent } from './customerdashboard/customerdashboard.component';

import { RegisteruserComponent } from './registeruser/registeruser.component';
import { RegisterAdminComponent } from './registeradmin/registeradmin.component';
import { EventRegistrationViewComponent } from './eventregistrationview/eventregistrationview.component';


const appRoutes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },  
  { path: 'registeruser', component: RegisteruserComponent },  
  { path: 'registerAdmin', component: RegisterAdminComponent },  
  { path: 'admindashboard', component: admindashboardComponent },
  { path: 'eventregistrationview', component: EventRegistrationViewComponent },
  { path: 'customerdashboard', component: customerdashboardComponent },
  { path: 'register-event', component: RegisterEventComponent },
 
  {
    path: 'dashboard',   
    canActivate: [CanActivateRouteGuard],
    children: [
      /*{ path: 'view/noteview', component: NoteViewComponent },          
      { path: '', redirectTo: 'view/noteview', pathMatch: 'full' },
      { path: 'view/editview', component: EditNoteOpenerComponent },
      { path: 'note/:noteId/edit', component: EditNoteOpenerComponent, outlet: 'noteEditOutlet' },

      { path: 'view/categoryview', component:CategoryviewComponent},
      { path: '', redirectTo: 'categoryview', pathMatch: 'full' },
      { path: 'view/editcategory', component: EditCategoryViewComponent },
      { path: 'category/:categoryId/edit', component: EditCategoryViewComponent, outlet: 'CategoryOutlet' },

      { path: 'view/reminderview', component: ReminderviewComponent },
      { path: '', redirectTo: 'reminderview', pathMatch: 'full' },
      { path: 'view/editreminder', component: EditReminderViewComponent },
      { path: 'reminder/:reminderId/edit', component: EditReminderViewComponent, outlet: 'ReminderOutlet' }*/
    ]
  }
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,   
    LoginComponent,        
    RegisterComponent,
    admindashboardComponent,   
    customerdashboardComponent,
    EventRegistrationViewComponent,
    RegisterEventComponent,
    RegisterComponent,
    RegisteruserComponent,
    RegisterAdminComponent    
       
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatCardModule,
    MatExpansionModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    FormsModule,
    HttpClientModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatDatepickerModule,
        MatNativeDateModule, 
    RouterModule.forRoot(appRoutes)
  ],
  providers: [    
    AuthenticationService,
    RouterService,    
    CanActivateRouteGuard
  ],
  bootstrap: [AppComponent],
  entryComponents: [],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})

export class AppModule { }
